package com.hmt.agent.sh.utils.excel;

public interface BaseRowPacker<T>{
	public T getInstance();
	public boolean packing(Object obj,String key,String text);
}
