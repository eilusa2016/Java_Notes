package com.hmt.agent.sh.utils.excel;

public interface BaseColumnFormat<T>{
	public String format(String col,T t);
}
