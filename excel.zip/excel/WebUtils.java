package com.hmt.agent.sh.utils.excel;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.RandomStringUtils;
import com.hmt.core.utils.SecurityUtil;

public class WebUtils {
	
	public static void write(HttpServletResponse resp,String html){
		try {
			resp.getWriter().write(html);
			resp.getWriter().flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String createToken() {
		return SecurityUtil.getInstance().md5(System.currentTimeMillis()+RandomStringUtils.randomAlphanumeric(10));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void toExcelDowlond(HttpServletResponse resp,String fileName,String title,List<?> list,String[] heads,String[] keys,BaseColumnFormat format) {
		ExcelCreator<?> creator = ExcelUtils.buildCreator(list);
		creator.setFileName(fileName);
		creator.setTitle(title);
		creator.setColTitles(heads);
		creator.setColKeys(keys);
		creator.setFormat(format);
		WebUtils.write(resp,creator);
	}
	
	public static void write(HttpServletResponse resp,ExcelCreator<?> creator) {
//		没搞清楚,反正从上下文取的response是个傻逼,文件下载成功后会内部跳转一把
//		HttpServletResponse resp = getResp();
		setResponseHeader(resp, creator.getFileName());
		try {
			creator.createAndWrite(resp.getOutputStream());
			resp.getOutputStream().flush();
			//resp.getOutputStream().close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static void setResponseHeader(HttpServletResponse response, String fileName) {  
        try {  
             try {  
                  fileName = new String(fileName.getBytes(),"ISO8859-1");  
             } catch (UnsupportedEncodingException e) {  
                  e.printStackTrace();  
             }  
             response.setContentType("application/octet-stream;charset=ISO8859-1");  
             response.setHeader("Content-Disposition", "attachment;filename="+ fileName);  
             response.addHeader("Pargam", "no-cache");  
             response.addHeader("Cache-Control", "no-cache");  
        } catch (Exception ex) {  
             ex.printStackTrace();  
        }  
   }
	
	
	
}
